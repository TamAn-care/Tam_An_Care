# Resident Leave & Temporary Absence (RLA)

## Status

Business scope approved. **Not yet implementation-accepted.**

## RLA-BR-01 - Meal-fee deduction rule

For planned resident leave/temporary absence:

1. Family/guardian should notify Tam An at least **48 hours in advance** to qualify for meal-fee deduction for the eligible leave period.
2. If notice is **less than 48 hours**, the **first leave day remains chargeable**.
3. For subsequent leave days:
   - if the family updates/confirms the leave plan, eligible subsequent leave days can receive the meal-fee deduction;
   - if the family provides no update about the leave plan, those days are not deducted.

## Implementation principles for future work

- Preserve canonical resident identity and auditability.
- Record who reported/updated the leave plan and when.
- Avoid retroactive mutation of canonical consumption records.
- Make billing/meal deduction derivable and explainable.
- Human actor authority must be explicit for staff-side changes.
- Lists must be bounded/paginated; no hard resident maximum.
