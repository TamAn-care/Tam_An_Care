# Architecture and Safety Constraints

## Baseline preservation

- Prefer immutable filesystem checkpoints + SHA256 when Git authority is absent.
- Historical preflight found no Git repository; do not initialize one without explicit authorization.
- Preserve accepted source/runtime/database baselines before any mutation.
- Use isolated acceptance environments for schema/runtime tests when possible.
- Master health must remain HTTP 200 unless an explicitly authorized deployment gate says otherwise.
- Failed controlled implementations must rollback source and clean isolated runtime artifacts.

## Human authority

- Human actor identity is mandatory for operational/lifecycle mutations.
- AI must not be granted cost approval or period-lock authority.
- Preserve human review/approval in family-report workflows.

## Data architecture

- Do not create a second inventory ledger.
- Do not create a second resident-consumption domain.
- Do not retroactively mutate consumption history.
- Usage-derived cost must reference canonical consumption.
- Cost events must reference a resident.
- Reuse existing W family-report domain; do not create a second family-report module.
- Reuse existing Care Plan domain in Resident Lifecycle.
- Discharge is a lifecycle event, not resident deletion.
- Preserve historical clinical/care/report/audit data.

## Scale/list behavior

- No hard resident-count ceiling.
- 200 concurrent residents is a capacity baseline, not a maximum.
- Avoid load-all queries.
- Use bounded/paginated lists.
- OPS-5 authority: default list limit 50, max 100.
- AA overview: page size 100.

## UI

- Vietnamese-first staff UX.
- Do not add duplicate staff UI when an existing accepted surface can be reused.

## Security

- Production auth evidence used bearer + actor headers.
- SEC-L3 readiness may be registered, but full SEC-L3 compliance must NOT be claimed unless separately accepted.
