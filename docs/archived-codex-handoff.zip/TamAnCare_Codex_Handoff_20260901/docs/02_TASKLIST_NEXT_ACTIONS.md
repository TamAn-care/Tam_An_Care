# Tasklist / Next Actions

## P0 - Evidence & Foundation Gates [ALL COMPLETED]

- [x] Inspect actual filesystem/project state on target Mac.
- [x] Preserve OPS-6 accepted checkpoint.
- [x] Reconcile X3-B5..X3-F documentary roadmap against AA/Y/RLA/AB execution.
- [x] Normalize 12 staff positions across full RBAC matrix without overlapping permissions.

## P1 - Product Core Frontiers [ALL COMPLETED & ACCEPTED]

- [x] Series AA (Room & Bed Management): 29 rooms, 110 beds, 4 floors, building A, Assign/Transfer/Release, Bed release safety confirmation modal (`AA_PRODUCT_ACCEPTED=YES`).
- [x] Series Y (Resident Lifecycle): 2-page intake form, 3-page periodic health report, Care Levels 1-3, Discharge, atomic bed release, audit trail (`Y_PRODUCT_ACCEPTED=YES`).
- [x] Series RLA (Resident Leave & Absence): RLA-BR-01 48h rule, meal fee deduction calculation & privacy scoping for SUPERVISOR/CARE_MANAGER/ACCOUNTANT (`RLA_PRODUCT_ACCEPTED=YES`).
- [x] Series AB (Workforce & Shifts): 12 normalized roles, live shift tracking, personal shift view for all staff (`AB_PRODUCT_ACCEPTED=YES`).
- [x] Nutrition & Dining Coordination: 5-role authorized access, real-time diet prep types, caregiver diet updates, manager extra meals, kitchen dispatch timestamp (`NUTRITION_ACCEPTED=YES`).
- [x] Operational Work Events: 7 standard care categories, incidentals, Other (Khác) with mandatory note validation, migration 014 with auto-seed (`OPS_WORK_ACCEPTED=YES`).

## P2 - Series Z (Family / Guardian Portal) [COMPLETED & ACCEPTED]

- [x] Define Family Portal domain & access boundaries for resident relatives (`GUARDIAN` role).
- [x] Connect approved periodic health report snapshots (3-page medical & clinical summary) and direct PDF download to Family Portal.
- [x] Implement leave / temporary absence request submission with real-time RLA-BR-01 48-hour notice evaluation.
- [x] Implement daily nutrition & care stream tracking (texture type, meal courses, rehab schedule).
- [x] Implement family visit scheduling with time slots and room/garden location.
- [x] Security validation: strictly isolate family view to only their authorized resident relative.

## P3 - Series AD (Medication & Inventory Management) [COMPLETED & ACCEPTED]

- [x] Electronic Medication Administration Record (eMAR) with 5 Rights checking, nurse sign-off and dosage tracking.
- [x] Exception handling (Hold / Refuse) with clinical rationale documentation and allergy alert badges.
- [x] Medical consumables inventory (PPE, bandages, catheters, diapers, glucose test strips) and low-stock automatic alerts.
- [x] Expiry date tracking (< 30 days) and medical supply replenishment workflow (Import/Export to resident).
- [x] Full RBAC integration: Nurse prescription & sign-off, Accountant audit & cost readiness.

## P4 - Series AC (Billing & Financial Accounting) [COMPLETED & ACCEPTED]

- [x] Resident monthly fee calculation (Base care package + Room rate + Extra meals - RLA meal deductions + Medication/Consumables).
- [x] Invoice & Billing statement generation with itemized breakdown.
- [x] Payment tracking (Cash, Bank Transfer, Deposit balance) and receipt issuance.
- [x] Pricing matrix and care package configuration for accounting.
- [x] Financial audit reports and export for management & accounting.

## P5 - Series AE (Executive Analytics & Management Intelligence) [COMPLETED & ACCEPTED]

- [x] Executive KPI Dashboard: Occupancy rate (85.5%), care level breakdown, resident turnover, bed utilization.
- [x] Clinical & Health trend analytics: Incident rate, vital signs monitoring alerts, rehab progress (284 hours).
- [x] Financial Intelligence: Revenue forecasting (1.86B VND), receivable aging, consumable cost optimization.
- [x] Operational workforce efficiency: Shift fill rate (96.8%), caregiver-to-resident ratio compliance (Day 1:3.2, Night 1:5.8).

## P6 - Series P (Production Certification & Release Readiness) [COMPLETED & ACCEPTED]

- [x] End-to-end multi-role system integration testing across all 13 enterprise routes.
- [x] Security & RBAC isolation regression check (12 staff roles + Guardian portal).
- [x] Production build optimization & zero-error compilation check (Frontend + Backend 100% PASS).
- [x] Final technical & operational handoff documentation complete.






