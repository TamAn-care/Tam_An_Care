# Features Implemented / Evidenced

This list is evidence-based and intentionally distinguishes source presence from product acceptance.

## Core platform / care domains already present

Backend modules/controllers observed include:
- Admissions and admission classification
- AI engine / AI governance / early warning
- Care actions and care-action bridge
- Care-plan governance
- Care-task execution
- Clinical observations
- Cross-domain integration
- Fall/mobility
- Health reports
- Incidents
- Infection control
- Medication and medication safety
- Nutrition/hydration
- Operational care view/dashboard
- Pain/comfort
- Personal care
- Resident access administration/scope
- Residents
- Responsibility acceptance
- Safeguarding
- Skin/wound
- Sleep/rest
- Staff actors
- Warning review
- Authorization services for start-review, resolution, reopen
- Operational work
- Inventory
- Kitchen operations
- Resident cost

Frontend areas observed include admissions, care view, dashboard, health reports, residents, staff access, system status, actor/session/role controls.

## Resident Access / staff workflow

Historical acceptance evidence covered:
- human actor propagation/guard
- staff listing
- resident access listing
- authorization rejection
- responsive Staff Access UI
- backend health
- database cleanliness
- assignment and transfer history
- review lifecycle: start review -> resolve -> reopen
- historical resolution preservation
- audit sequence preservation

## OPS-related operational domains

Evidence shows operational work foundation, event-type/audit migrations, inventory lot/consumption work, kitchen operations, resident-cost authority design, and W unified family-report integration.

### OPS-6 / W unified family report integration

Explicit accepted properties:
- existing W reused
- no second family-report module
- resident consumption included in W
- reconciled/locked cost periods included
- open cost periods excluded
- human review preserved
- human approval preserved
- approved snapshot PDF preserved
- authorized recipient control preserved
- delivery audit preserved
- Vietnamese UI requirement satisfied without new staff UI
- SEC-L3 readiness overlay registered; full compliance NOT claimed

## AA Room / Bed Management - accepted in newer evidence

Capabilities evidenced:
- building/floor/room/bed hierarchy
- assign resident to bed
- transfer bed
- release bed
- bed availability/status control
- occupied-bed status-change rejection
- reserved/generic assignment rejection
- assignment history
- audit trail
- legacy projection compatibility
- bounded overview (page size 100)
- filters and search
- pagination
- setup/navigation UI
- scale/performance regression

## Y Resident Lifecycle - implemented through Y3C, not yet product-accepted

Architecture/implementation evidence includes:
- reuse Admission as pre-admission/final-admission authority
- reuse AA active bed assignment as occupancy authority
- reuse existing Care Plan domain; no second care-plan model
- discharge/end-of-service as lifecycle event, not deletion
- preserve resident clinical/care/report/history data
- atomically end active bed assignment on discharge
- mandatory human actor for lifecycle mutation
- repeated discharge idempotent/conflict-safe
- inactive resident cannot receive accommodation
- no hard resident-count limit
- backward-compatible readers
- backend resident-lifecycle module
- frontend lifecycle API/UI

## RLA - approved business rule only, not implementation

Resident Leave & Temporary Absence scope is approved. See `07_BUSINESS_RULES_RLA.md`.
