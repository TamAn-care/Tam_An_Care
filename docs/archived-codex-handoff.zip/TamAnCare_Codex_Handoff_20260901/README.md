# TamAnCare - Codex Handoff

**Handoff date:** 2026-09-01

This package is a conservative, evidence-first handoff for continuing TamAnCare development with Codex. It separates:

1. **Accepted product/business work**
2. **OPS execution evidence**
3. **Historical Master Roadmap authority**
4. **Newer downstream work (AA and Y)**
5. **Known inconsistencies/gaps that MUST be reconciled before autonomous continuation**

## Start here

Read in this order:

1. `docs/00_CURRENT_STATE.md`
2. `docs/01_MASTER_ROADMAP.md`
3. `docs/02_TASKLIST_NEXT_ACTIONS.md`
4. `docs/03_FEATURES_IMPLEMENTED.md`
5. `docs/04_TESTS_AND_RESULTS.md`
6. `docs/05_OPS_STATUS_AND_GAPS.md`
7. `docs/06_ARCHITECTURE_AND_SAFETY_CONSTRAINTS.md`
8. `docs/07_BUSINESS_RULES_RLA.md`
9. `docs/08_EVIDENCE_INDEX.md`
10. `CODEX_START_PROMPT.md`

## Critical rule

Do **not** infer that a later PASS automatically closes an earlier missing gate. In particular, OPS-5 has authority-discovery PASS evidence but no independently located implementation/closeout acceptance marker in the retrieved evidence, while OPS-6 is explicitly CLOSED/HUMAN ACCEPTED. Treat this as an acceptance-chain gap requiring reconciliation, not as permission to rerun or skip blindly.

## Repository warning

Historical preflight evidence reported that no Git repository was available at that checkpoint. Do not initialize Git merely to make the handoff look conventional. First inspect the actual machine state and preserve the existing immutable checkpoint/SHA256 discipline if that is still the active authority model.
