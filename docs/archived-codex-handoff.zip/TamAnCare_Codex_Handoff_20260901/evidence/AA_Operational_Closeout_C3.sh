#!/bin/bash
set -Eeuo pipefail

ROOT="/Users/anhha/Downloads/TamAnCare_V7_4_3_Development"
API="$ROOT/api"
FE="$ROOT/frontend"
MIG="$ROOT/database/migrations/20260831_010_aa_accommodation_room_bed.sql"

MASTER_PG="tamancare_v7_4_3_development-postgres-1"
MASTER_DB="taman_care"
DBU="taman"

STAMP="$(date +%Y%m%d_%H%M%S)"
BK="$ROOT/V8.0/checkpoints/aa_closeout_c3_${STAMP}"
TMP="$(mktemp -d /tmp/aa-c2.XXXXXX)"

NET="aa_c3_net_${STAMP}"
IPG="aa_c3_pg_${STAMP}"
IAPI="aa_c3_api_${STAMP}"
IMG="tamancare-aa-c2:${STAMP}"
ISO_DB="taman_aa_c2"

NAV_FILE=""
MUTATED=0

mkdir -p "$BK/api" "$BK/frontend"

cleanup_runtime() {
  set +e
  docker rm -f "$IAPI" "$IPG" >/dev/null 2>&1 || true
  docker network rm "$NET" >/dev/null 2>&1 || true
  docker image rm "$IMG" >/dev/null 2>&1 || true
  docker exec "$MASTER_PG" rm -f "/tmp/aa_c3_master_${STAMP}.dump" >/dev/null 2>&1 || true
  rm -rf "$TMP"
}

rollback_source() {
  set +e
  [ "$MUTATED" = "1" ] || return 0

  echo "ROLLBACK: restoring C3 checkpoint..."

  cp "$BK/api/accommodation.controller.ts" \
    "$API/src/accommodation/accommodation.controller.ts" 2>/dev/null || true

  cp "$BK/api/accommodation.service.ts" \
    "$API/src/accommodation/accommodation.service.ts" 2>/dev/null || true

  cp "$BK/frontend/accommodation.ts" \
    "$FE/src/api/accommodation.ts" 2>/dev/null || true

  cp "$BK/frontend/AccommodationPage.tsx" \
    "$FE/src/features/accommodation/AccommodationPage.tsx" 2>/dev/null || true

  if [ -f "$BK/frontend/nav_file_path" ]; then
    NAV="$(cat "$BK/frontend/nav_file_path")"
    cp "$BK/frontend/nav_file.tsx" "$NAV" 2>/dev/null || true
  fi

  echo "ROLLBACK_COMPLETE=YES"
}

fail() {
  echo
  echo "======================================================================"
  echo " STATUS: AA OPERATIONAL CLOSEOUT C3 FAILED"
  echo " FAILURE=$1"
  rollback_source
  cleanup_runtime
  echo " MASTER_DATABASE_MUTATION=NO"
  echo " MASTER_RUNTIME_REDEPLOYMENT=NO"
  echo " AA_PRODUCT_ACCEPTED=NO"
  echo " NEXT=STOP_AND_RETURN_OUTPUT"
  echo "======================================================================"
  exit 1
}

trap cleanup_runtime EXIT

echo "======================================================================"
echo " TAM AN CARE — AA ROOM/BED"
echo " OPERATIONAL UI + BOUNDED OVERVIEW + SCALE + REGRESSION CLOSEOUT C3"
echo "======================================================================"

echo
echo "STEP 1 — MASTER SAFETY + CHECKPOINT"

H0="$(curl -sS -o /dev/null -w '%{http_code}' \
  http://127.0.0.1:3000/api/health 2>/dev/null || true)"
[ "$H0" = "200" ] || fail "MASTER_HEALTH_NOT_200"

M0="$(docker exec "$MASTER_PG" psql -X -U "$DBU" -d "$MASTER_DB" -Atc "
SELECT count(*)
FROM pg_tables
WHERE schemaname='public'
AND tablename IN (
  'accommodation_buildings',
  'accommodation_floors',
  'accommodation_rooms',
  'accommodation_beds',
  'bed_assignments',
  'accommodation_audit_events'
);" 2>/dev/null)"
[ "$M0" = "0" ] || fail "MASTER_AA_TABLES_NOT_ZERO"

for F in \
  "$API/src/accommodation/accommodation.controller.ts" \
  "$API/src/accommodation/accommodation.service.ts" \
  "$FE/src/api/accommodation.ts" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" \
  "$MIG"
do
  [ -f "$F" ] || fail "REQUIRED_FILE_MISSING_$(basename "$F")"
done

NAV_FILE="$(python3 - <<'PY'
from pathlib import Path
import re

root=Path("/Users/anhha/Downloads/TamAnCare_V7_4_3_Development/frontend/src")
c=[]

for p in root.rglob("*.tsx"):
    try:
        s=p.read_text()
    except Exception:
        continue
    if "<nav" in s.lower() and "/residents" in s:
        c.append((len(s),str(p)))

if c:
    print(sorted(c)[0][1])
PY
)"

[ -n "$NAV_FILE" ] || fail "NAVIGATION_FILE_NOT_FOUND"

cp "$API/src/accommodation/accommodation.controller.ts" \
  "$BK/api/accommodation.controller.ts"
cp "$API/src/accommodation/accommodation.service.ts" \
  "$BK/api/accommodation.service.ts"
cp "$FE/src/api/accommodation.ts" \
  "$BK/frontend/accommodation.ts"
cp "$FE/src/features/accommodation/AccommodationPage.tsx" \
  "$BK/frontend/AccommodationPage.tsx"
cp "$NAV_FILE" "$BK/frontend/nav_file.tsx"
printf '%s' "$NAV_FILE" > "$BK/frontend/nav_file_path"

echo "MASTER_HEALTH=$H0"
echo "MASTER_AA_TABLES=$M0"
echo "NAVIGATION_FILE=$NAV_FILE"
echo "CHECKPOINT=$BK"
echo "PASS: MASTER SAFE + CHECKPOINT"

echo
echo "STEP 2 — BACKEND CLOSEOUT PATCH"

cat > "$API/src/accommodation/accommodation.controller.ts" <<'TS'
import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Headers,
  Param,
  Post,
  Query,
} from '@nestjs/common';
import { AccommodationService } from './accommodation.service';

@Controller('api/accommodation')
export class AccommodationController {
  constructor(private readonly service: AccommodationService) {}

  private actor(actorId?: string, actorRole?: string) {
    return {
      actorId: String(actorId ?? '').trim(),
      actorRole: String(actorRole ?? '').trim().toUpperCase(),
    };
  }

  private rejectBodyActor(body: any) {
    if (
      body &&
      (
        body.actorId !== undefined ||
        body.actorRole !== undefined ||
        body.assignedBy !== undefined ||
        body.endedBy !== undefined
      )
    ) {
      throw new BadRequestException(
        'Actor identity must come from authenticated request context',
      );
    }
  }

  @Get('overview')
  overview(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Query('buildingId') buildingId?: string,
    @Query('floorId') floorId?: string,
    @Query('roomId') roomId?: string,
    @Query('status') status?: string,
    @Query('search') search?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
  ) {
    return this.service.overviewPaged(
      this.actor(actorId, actorRole),
      buildingId,
      floorId,
      roomId,
      status,
      search,
      limit,
      offset,
    );
  }

  @Get('buildings')
  buildings(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
  ) {
    return this.service.listBuildings(
      this.actor(actorId, actorRole),
    );
  }

  @Post('buildings')
  createBuilding(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.createBuilding(
      this.actor(actorId, actorRole),
      body,
    );
  }

  @Get('floors')
  floors(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Query('buildingId') buildingId?: string,
  ) {
    return this.service.listFloors(
      this.actor(actorId, actorRole),
      buildingId,
    );
  }

  @Post('floors')
  createFloor(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.createFloor(
      this.actor(actorId, actorRole),
      body,
    );
  }

  @Get('rooms')
  rooms(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Query('floorId') floorId?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
  ) {
    return this.service.listRooms(
      this.actor(actorId, actorRole),
      floorId,
      limit,
      offset,
    );
  }

  @Post('rooms')
  createRoom(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.createRoom(
      this.actor(actorId, actorRole),
      body,
    );
  }

  @Get('beds')
  beds(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Query('roomId') roomId?: string,
    @Query('status') status?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
  ) {
    return this.service.listBeds(
      this.actor(actorId, actorRole),
      roomId,
      status,
      limit,
      offset,
    );
  }

  @Post('beds')
  createBed(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.createBed(
      this.actor(actorId, actorRole),
      body,
    );
  }

  @Post('beds/:bedId/status')
  setBedStatus(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Param('bedId') bedId?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.setBedStatus(
      this.actor(actorId, actorRole),
      bedId,
      body?.status,
    );
  }

  @Post('beds/:bedId/assign')
  assign(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Param('bedId') bedId?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.assign(
      this.actor(actorId, actorRole),
      bedId,
      body?.residentId,
    );
  }

  @Post('residents/:residentId/transfer')
  transfer(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Param('residentId') residentId?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.transfer(
      this.actor(actorId, actorRole),
      residentId,
      body?.bedId,
    );
  }

  @Post('residents/:residentId/release')
  release(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Param('residentId') residentId?: string,
    @Body() body?: any,
  ) {
    this.rejectBodyActor(body);
    return this.service.release(
      this.actor(actorId, actorRole),
      residentId,
      body?.reason,
    );
  }

  @Get('residents/:residentId/history')
  history(
    @Headers('x-actor-id') actorId?: string,
    @Headers('x-actor-role') actorRole?: string,
    @Param('residentId') residentId?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
  ) {
    return this.service.history(
      this.actor(actorId, actorRole),
      residentId,
      limit,
      offset,
    );
  }
}
TS

python3 - <<'PY'
from pathlib import Path

p=Path("/Users/anhha/Downloads/TamAnCare_V7_4_3_Development/api/src/accommodation/accommodation.service.ts")
s=p.read_text()

old="!['AVAILABLE','RESERVED'].includes(x.bed_status)"
if old not in s:
    raise SystemExit("EXACT_RESERVED_TARGET_NOT_FOUND")

s=s.replace(old, "x.bed_status!=='AVAILABLE'", 1)

if "async overviewPaged(" not in s:
    anchor="  async listBuildings("
    if anchor not in s:
        raise SystemExit("LIST_BUILDINGS_ANCHOR_NOT_FOUND")

    block='''  async overviewPaged(
    a: Actor,
    buildingId?: string,
    floorId?: string,
    roomId?: string,
    status?: string,
    search?: string,
    limit?: string,
    offset?: string,
  ) {
    await this.auth(a);
    const p = this.page(limit, offset);
    const st =
      status && status !== 'ALL'
        ? status.toUpperCase()
        : null;
    const q = search?.trim() || null;

    const summary = await this.db.query(`
      SELECT
        COUNT(*)::int total,
        COUNT(x.assignment_id)::int occupied,
        COUNT(*) FILTER(
          WHERE b.status='RESERVED'
            AND x.assignment_id IS NULL
        )::int reserved,
        COUNT(*) FILTER(
          WHERE b.status IN(
            'TEMPORARILY_UNAVAILABLE',
            'MAINTENANCE',
            'INACTIVE'
          )
        )::int unavailable
      FROM accommodation_beds b
      LEFT JOIN bed_assignments x
        ON x.bed_id=b.bed_id
       AND x.ended_at IS NULL
    `);

    const rows = await this.db.query(`
      SELECT
        bu.building_id "buildingId",
        bu.code "buildingCode",
        bu.name "buildingName",
        f.floor_id "floorId",
        f.code "floorCode",
        f.name "floorName",
        f.floor_number "floorNumber",
        r.room_id "roomId",
        r.code "roomCode",
        r.name "roomName",
        r.room_type "roomType",
        b.bed_id "bedId",
        b.code "bedCode",
        b.name "bedName",
        CASE
          WHEN x.assignment_id IS NOT NULL THEN 'OCCUPIED'
          ELSE b.status
        END "bedStatus",
        x.assignment_id "assignmentId",
        x.resident_id "residentId",
        res.display_name "residentName",
        res.care_level "careLevel",
        x.assigned_at "assignedAt",
        COUNT(*) OVER()::int "totalCount"
      FROM accommodation_beds b
      JOIN accommodation_rooms r
        ON r.room_id=b.room_id
      JOIN accommodation_floors f
        ON f.floor_id=r.floor_id
      JOIN accommodation_buildings bu
        ON bu.building_id=f.building_id
      LEFT JOIN bed_assignments x
        ON x.bed_id=b.bed_id
       AND x.ended_at IS NULL
      LEFT JOIN residents res
        ON res.resident_id=x.resident_id
      WHERE
        ($1::text IS NULL OR bu.building_id=$1)
        AND ($2::text IS NULL OR f.floor_id=$2)
        AND ($3::text IS NULL OR r.room_id=$3)
        AND (
          $4::text IS NULL
          OR
          CASE
            WHEN x.assignment_id IS NOT NULL THEN 'OCCUPIED'
            ELSE b.status
          END=$4
        )
        AND (
          $5::text IS NULL
          OR LOWER(
            CONCAT_WS(
              ' ',
              bu.name,bu.code,
              f.name,f.code,
              r.name,r.code,
              b.name,b.code,
              res.display_name
            )
          ) LIKE LOWER('%'||$5||'%')
        )
      ORDER BY
        bu.sort_order,
        bu.code,
        f.sort_order,
        f.floor_number NULLS LAST,
        f.code,
        r.sort_order,
        r.code,
        b.sort_order,
        b.code
      LIMIT $6 OFFSET $7
    `,[
      buildingId || null,
      floorId || null,
      roomId || null,
      st,
      q,
      p.limit,
      p.offset,
    ]);

    const z = summary.rows[0] ?? {
      total: 0,
      occupied: 0,
      reserved: 0,
      unavailable: 0,
    };

    return {
      summary: {
        ...z,
        available: Math.max(
          0,
          z.total-z.occupied-z.reserved-z.unavailable,
        ),
        occupancyPercentage:
          z.total
            ? Math.round(z.occupied/z.total*10000)/100
            : 0,
      },
      items: rows.rows,
      limit: p.limit,
      offset: p.offset,
      total: rows.rows[0]?.totalCount ?? 0,
    };
  }

'''
    s=s.replace(anchor, block+anchor, 1)

if "async setBedStatus(" not in s:
    anchor="  async assign("
    if anchor not in s:
        raise SystemExit("ASSIGN_ANCHOR_NOT_FOUND")

    block='''  async setBedStatus(
    a: Actor,
    bid?: string,
    rawStatus?: string,
  ) {
    await this.auth(a, true);
    const bed = this.req(bid, 'bedId');
    const status = this.req(rawStatus, 'status').toUpperCase();

    const allowed = new Set([
      'AVAILABLE',
      'TEMPORARILY_UNAVAILABLE',
      'MAINTENANCE',
      'INACTIVE',
    ]);

    if (!allowed.has(status)) {
      throw new BadRequestException(
        'Unsupported operational bed status',
      );
    }

    return this.db.withTransaction(async c => {
      const q = await c.query(`
        SELECT
          b.bed_id,
          b.status bed_status,
          r.status room_status,
          f.status floor_status,
          bu.status building_status
        FROM accommodation_beds b
        JOIN accommodation_rooms r
          ON r.room_id=b.room_id
        JOIN accommodation_floors f
          ON f.floor_id=r.floor_id
        JOIN accommodation_buildings bu
          ON bu.building_id=f.building_id
        WHERE b.bed_id=$1
        FOR UPDATE OF b,r,f,bu
      `,[bed]);

      if (q.rowCount !== 1) {
        throw new NotFoundException('Bed not found');
      }

      const current = q.rows[0];

      const active = await c.query(`
        SELECT assignment_id
        FROM bed_assignments
        WHERE bed_id=$1
          AND ended_at IS NULL
        FOR UPDATE
      `,[bed]);

      if (active.rowCount) {
        throw new ConflictException(
          'Occupied bed status cannot be changed',
        );
      }

      if (
        status === 'AVAILABLE' &&
        (
          current.room_status !== 'AVAILABLE' ||
          current.floor_status !== 'ACTIVE' ||
          current.building_status !== 'ACTIVE'
        )
      ) {
        throw new ConflictException(
          'Parent hierarchy is unavailable',
        );
      }

      const updated = await c.query(`
        UPDATE accommodation_beds
        SET status=$2,updated_at=now()
        WHERE bed_id=$1
        RETURNING
          bed_id "bedId",
          room_id "roomId",
          code,
          name,
          status
      `,[bed,status]);

      const next=updated.rows[0];

      await this.audit(
        c,
        'BED_STATUS_CHANGED',
        'BED',
        bed,
        null,
        a,
        {status:current.bed_status},
        next,
      );

      return next;
    });
  }

'''
    s=s.replace(anchor, block+anchor, 1)

p.write_text(s)
PY

MUTATED=1

grep -q "async overviewPaged" \
  "$API/src/accommodation/accommodation.service.ts" ||
  fail "BOUNDED_OVERVIEW_PATCH_MISSING"

grep -q "async setBedStatus" \
  "$API/src/accommodation/accommodation.service.ts" ||
  fail "STATUS_METHOD_PATCH_MISSING"

grep -q "x.bed_status!=='AVAILABLE'" \
  "$API/src/accommodation/accommodation.service.ts" ||
  fail "RESERVED_SAFETY_PATCH_MISSING"

if grep -q "\!\['AVAILABLE','RESERVED'\].includes(x.bed_status)" \
  "$API/src/accommodation/accommodation.service.ts"; then
  fail "RESERVED_GENERIC_ASSIGNMENT_STILL_ALLOWED"
fi

echo "PASS: BACKEND CLOSEOUT PATCH"

echo
echo "STEP 3 — FRONTEND OPERATIONAL API"

cat > "$FE/src/api/accommodation.ts" <<'TS'
import { apiRequest } from './client';
import type { HumanActorSession } from '../types/actor';

export interface AccommodationSummary {
  total: number;
  occupied: number;
  available: number;
  reserved: number;
  unavailable: number;
  occupancyPercentage: number;
}

export interface AccommodationItem {
  buildingId: string;
  buildingCode: string;
  buildingName: string;
  floorId: string;
  floorCode: string;
  floorName: string;
  floorNumber: number | null;
  roomId: string;
  roomCode: string;
  roomName: string;
  roomType: string | null;
  bedId: string;
  bedCode: string;
  bedName: string;
  bedStatus: string;
  assignmentId: string | null;
  residentId: string | null;
  residentName: string | null;
  careLevel: string | null;
  assignedAt: string | null;
}

export interface AccommodationOverview {
  summary: AccommodationSummary;
  items: AccommodationItem[];
  limit: number;
  offset: number;
  total: number;
}

export interface Building {
  buildingId: string;
  code: string;
  name: string;
  status: string;
}

export interface Floor {
  floorId: string;
  buildingId: string;
  code: string;
  name: string;
  floorNumber: number | null;
  status: string;
}

export interface Room {
  roomId: string;
  floorId: string;
  code: string;
  name: string;
  roomType: string | null;
  status: string;
}

function queryString(
  values: Record<string, string | number | undefined>,
) {
  const p = new URLSearchParams();

  Object.entries(values).forEach(([k,v]) => {
    if (
      v !== undefined &&
      v !== '' &&
      v !== 'ALL'
    ) {
      p.set(k,String(v));
    }
  });

  const q=p.toString();
  return q ? `?${q}` : '';
}

export function getAccommodationOverview(
  actor: HumanActorSession,
  filters: {
    buildingId?: string;
    floorId?: string;
    roomId?: string;
    status?: string;
    search?: string;
    limit?: number;
    offset?: number;
  },
) {
  return apiRequest<AccommodationOverview>(
    `/api/accommodation/overview${queryString(filters)}`,
    { actor },
  );
}

export function listBuildings(
  actor: HumanActorSession,
) {
  return apiRequest<Building[]>(
    '/api/accommodation/buildings',
    { actor },
  );
}

export function listFloors(
  actor: HumanActorSession,
  buildingId?: string,
) {
  return apiRequest<Floor[]>(
    `/api/accommodation/floors${queryString({buildingId})}`,
    { actor },
  );
}

export function listRooms(
  actor: HumanActorSession,
  floorId?: string,
) {
  return apiRequest<{
    items: Room[];
    limit: number;
    offset: number;
    total: number;
  }>(
    `/api/accommodation/rooms${queryString({
      floorId,
      limit: 100,
      offset: 0,
    })}`,
    { actor },
  );
}

export function createBuilding(
  actor: HumanActorSession,
  input: { code: string; name: string },
) {
  return apiRequest('/api/accommodation/buildings', {
    method: 'POST',
    actor,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  });
}

export function createFloor(
  actor: HumanActorSession,
  input: {
    buildingId: string;
    code: string;
    name: string;
    floorNumber?: number | null;
  },
) {
  return apiRequest('/api/accommodation/floors', {
    method: 'POST',
    actor,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  });
}

export function createRoom(
  actor: HumanActorSession,
  input: {
    floorId: string;
    code: string;
    name: string;
    roomType?: string;
  },
) {
  return apiRequest('/api/accommodation/rooms', {
    method: 'POST',
    actor,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  });
}

export function createBed(
  actor: HumanActorSession,
  input: {
    roomId: string;
    code: string;
    name: string;
  },
) {
  return apiRequest('/api/accommodation/beds', {
    method: 'POST',
    actor,
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input),
  });
}

export function assignBed(
  actor: HumanActorSession,
  bedId: string,
  residentId: string,
) {
  return apiRequest(
    `/api/accommodation/beds/${encodeURIComponent(bedId)}/assign`,
    {
      method: 'POST',
      actor,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ residentId }),
    },
  );
}

export function transferBed(
  actor: HumanActorSession,
  residentId: string,
  bedId: string,
) {
  return apiRequest(
    `/api/accommodation/residents/${encodeURIComponent(residentId)}/transfer`,
    {
      method: 'POST',
      actor,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ bedId }),
    },
  );
}

export function releaseBed(
  actor: HumanActorSession,
  residentId: string,
) {
  return apiRequest(
    `/api/accommodation/residents/${encodeURIComponent(residentId)}/release`,
    {
      method: 'POST',
      actor,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ reason: 'OPERATIONAL_RELEASE' }),
    },
  );
}

export function setBedStatus(
  actor: HumanActorSession,
  bedId: string,
  status:
    | 'AVAILABLE'
    | 'TEMPORARILY_UNAVAILABLE'
    | 'MAINTENANCE'
    | 'INACTIVE',
) {
  return apiRequest(
    `/api/accommodation/beds/${encodeURIComponent(bedId)}/status`,
    {
      method: 'POST',
      actor,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ status }),
    },
  );
}
TS

echo "PASS: FRONTEND API"

echo
echo "STEP 4 — FRONTEND OPERATIONAL UI"

cat > "$FE/src/features/accommodation/AccommodationPage.tsx" <<'TSX'
import { useEffect, useMemo, useState } from 'react';
import {
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';

import {
  assignBed,
  createBed,
  createBuilding,
  createFloor,
  createRoom,
  getAccommodationOverview,
  listBuildings,
  listFloors,
  listRooms,
  releaseBed,
  setBedStatus,
  transferBed,
} from '../../api/accommodation';

import { listResidents } from '../../api/residents';
import { useActor } from '../../auth/ActorContext';

const PAGE_SIZE = 100;

type Action =
  | { type: 'ASSIGN'; bedId: string }
  | {
      type: 'TRANSFER';
      residentId: string;
      bedId: string;
    }
  | {
      type: 'RELEASE';
      residentId: string;
    }
  | {
      type: 'STATUS';
      bedId: string;
      status:
        | 'AVAILABLE'
        | 'TEMPORARILY_UNAVAILABLE'
        | 'MAINTENANCE';
    };

export default function AccommodationPage() {
  const { actor } = useActor();
  const qc = useQueryClient();

  const [residentId,setResidentId] = useState('');
  const [buildingId,setBuildingId] = useState('ALL');
  const [floorId,setFloorId] = useState('ALL');
  const [roomId,setRoomId] = useState('ALL');
  const [status,setStatus] = useState('ALL');
  const [search,setSearch] = useState('');
  const [offset,setOffset] = useState(0);

  const [bCode,setBCode] = useState('');
  const [bName,setBName] = useState('');
  const [fBuilding,setFBuilding] = useState('');
  const [fCode,setFCode] = useState('');
  const [fName,setFName] = useState('');
  const [rFloor,setRFloor] = useState('');
  const [rCode,setRCode] = useState('');
  const [rName,setRName] = useState('');
  const [bedRoom,setBedRoom] = useState('');
  const [bedCode,setBedCode] = useState('');
  const [bedName,setBedName] = useState('');

  useEffect(() => {
    setOffset(0);
  }, [buildingId,floorId,roomId,status,search]);

  const overview = useQuery({
    queryKey: [
      'accommodation-overview',
      buildingId,
      floorId,
      roomId,
      status,
      search,
      offset,
    ],
    queryFn: () => getAccommodationOverview(
      actor!,
      {
        buildingId,
        floorId,
        roomId,
        status,
        search,
        limit: PAGE_SIZE,
        offset,
      },
    ),
    enabled: Boolean(actor),
  });

  const buildings = useQuery({
    queryKey: ['accommodation-buildings'],
    queryFn: () => listBuildings(actor!),
    enabled: Boolean(actor),
  });

  const floors = useQuery({
    queryKey: ['accommodation-floors',buildingId],
    queryFn: () => listFloors(
      actor!,
      buildingId === 'ALL' ? undefined : buildingId,
    ),
    enabled: Boolean(actor),
  });

  const rooms = useQuery({
    queryKey: ['accommodation-rooms',floorId],
    queryFn: () => listRooms(
      actor!,
      floorId === 'ALL' ? undefined : floorId,
    ),
    enabled: Boolean(actor),
  });

  const residents = useQuery({
    queryKey: ['residents','accommodation'],
    queryFn: () => listResidents(actor),
    enabled: Boolean(actor),
  });

  const selectedResident =
    overview.data?.items.find(
      x => x.residentId === residentId,
    );

  const currentResidentLocation = useMemo(() => {
    if (!residentId) return undefined;
    return overview.data?.items.find(
      x => x.residentId === residentId,
    );
  }, [overview.data,residentId]);

  async function refresh() {
    await qc.invalidateQueries({
      queryKey: ['accommodation-overview'],
    });
    await qc.invalidateQueries({
      queryKey: ['accommodation-buildings'],
    });
    await qc.invalidateQueries({
      queryKey: ['accommodation-floors'],
    });
    await qc.invalidateQueries({
      queryKey: ['accommodation-rooms'],
    });
    await qc.invalidateQueries({
      queryKey: ['residents'],
    });
  }

  const action = useMutation({
    mutationFn: async (a: Action) => {
      if (!actor) {
        throw new Error(
          'Chưa xác định nhân viên thao tác.',
        );
      }

      if (a.type === 'ASSIGN') {
        if (!residentId) {
          throw new Error(
            'Chọn người cao tuổi trước.',
          );
        }
        return assignBed(
          actor,
          a.bedId,
          residentId,
        );
      }

      if (a.type === 'TRANSFER') {
        return transferBed(
          actor,
          a.residentId,
          a.bedId,
        );
      }

      if (a.type === 'RELEASE') {
        return releaseBed(
          actor,
          a.residentId,
        );
      }

      return setBedStatus(
        actor,
        a.bedId,
        a.status,
      );
    },
    onSuccess: refresh,
  });

  const setup = useMutation({
    mutationFn: async (
      kind:
        | 'BUILDING'
        | 'FLOOR'
        | 'ROOM'
        | 'BED',
    ) => {
      if (!actor) {
        throw new Error(
          'Chưa xác định nhân viên thao tác.',
        );
      }

      if (kind === 'BUILDING') {
        return createBuilding(
          actor,
          { code:bCode,name:bName },
        );
      }

      if (kind === 'FLOOR') {
        return createFloor(
          actor,
          {
            buildingId:fBuilding,
            code:fCode,
            name:fName,
          },
        );
      }

      if (kind === 'ROOM') {
        return createRoom(
          actor,
          {
            floorId:rFloor,
            code:rCode,
            name:rName,
          },
        );
      }

      return createBed(
        actor,
        {
          roomId:bedRoom,
          code:bedCode,
          name:bedName,
        },
      );
    },
    onSuccess: async () => {
      setBCode('');
      setBName('');
      setFCode('');
      setFName('');
      setRCode('');
      setRName('');
      setBedCode('');
      setBedName('');
      await refresh();
    },
  });

  if (!actor) {
    return (
      <main className="page">
        <h1>Phòng & Giường</h1>
        <p>Cần xác định nhân viên đang thao tác.</p>
      </main>
    );
  }

  const data=overview.data;
  const canPrev=offset>0;
  const canNext=
    Boolean(data) &&
    offset+PAGE_SIZE < (data?.total ?? 0);

  return (
    <main className="page">
      <div className="page-heading">
        <div>
          <h1>Phòng & Giường</h1>
          <p>
            Xếp giường, chuyển giường, trả giường
            và quản lý khả dụng tại một màn hình.
          </p>
        </div>
      </div>

      {data && (
        <section
          style={{
            display:'grid',
            gridTemplateColumns:
              'repeat(auto-fit,minmax(120px,1fr))',
            gap:10,
            marginBottom:16,
          }}
        >
          {[
            ['Tổng',data.summary.total],
            ['Đang sử dụng',data.summary.occupied],
            ['Còn trống',data.summary.available],
            ['Đã giữ',data.summary.reserved],
            ['Tạm ngưng',data.summary.unavailable],
            [
              'Công suất',
              `${data.summary.occupancyPercentage}%`,
            ],
          ].map(([k,v]) => (
            <article
              className="card"
              key={String(k)}
            >
              <small>{k}</small>
              <h2>{v}</h2>
            </article>
          ))}
        </section>
      )}

      <section
        className="card"
        style={{display:'grid',gap:10}}
      >
        <h2>Điều phối nhanh</h2>

        <label>
          Người cao tuổi
          <select
            value={residentId}
            onChange={
              e => setResidentId(e.target.value)
            }
          >
            <option value="">
              Chọn người cao tuổi
            </option>
            {(residents.data ?? []).map(
              ({resident}) => (
                <option
                  key={resident.residentId}
                  value={resident.residentId}
                >
                  {resident.displayName}
                </option>
              ),
            )}
          </select>
        </label>

        {currentResidentLocation && (
          <p>
            Vị trí hiện tại:{' '}
            <b>
              {currentResidentLocation.roomName}
              {' / '}
              {currentResidentLocation.bedName}
            </b>
          </p>
        )}

        <div
          style={{
            display:'grid',
            gridTemplateColumns:
              'repeat(auto-fit,minmax(150px,1fr))',
            gap:8,
          }}
        >
          <select
            value={buildingId}
            onChange={e => {
              setBuildingId(e.target.value);
              setFloorId('ALL');
              setRoomId('ALL');
            }}
          >
            <option value="ALL">Tất cả tòa</option>
            {(buildings.data ?? []).map(x => (
              <option
                key={x.buildingId}
                value={x.buildingId}
              >
                {x.name}
              </option>
            ))}
          </select>

          <select
            value={floorId}
            onChange={e => {
              setFloorId(e.target.value);
              setRoomId('ALL');
            }}
          >
            <option value="ALL">Tất cả tầng</option>
            {(floors.data ?? []).map(x => (
              <option
                key={x.floorId}
                value={x.floorId}
              >
                {x.name}
              </option>
            ))}
          </select>

          <select
            value={roomId}
            onChange={
              e => setRoomId(e.target.value)
            }
          >
            <option value="ALL">Tất cả phòng</option>
            {(rooms.data?.items ?? []).map(x => (
              <option
                key={x.roomId}
                value={x.roomId}
              >
                {x.name}
              </option>
            ))}
          </select>

          <select
            value={status}
            onChange={
              e => setStatus(e.target.value)
            }
          >
            <option value="ALL">
              Tất cả trạng thái
            </option>
            <option value="AVAILABLE">
              Còn trống
            </option>
            <option value="OCCUPIED">
              Đang sử dụng
            </option>
            <option value="RESERVED">
              Đã giữ
            </option>
            <option value="TEMPORARILY_UNAVAILABLE">
              Tạm ngưng
            </option>
            <option value="MAINTENANCE">
              Bảo trì
            </option>
            <option value="INACTIVE">
              Ngưng sử dụng
            </option>
          </select>

          <input
            value={search}
            onChange={
              e => setSearch(e.target.value)
            }
            placeholder="Tìm phòng, giường, cư dân…"
          />
        </div>

        {action.error && (
          <p role="alert">
            {action.error instanceof Error
              ? action.error.message
              : 'Không thể hoàn tất thao tác.'}
          </p>
        )}
      </section>

      <section
        style={{
          display:'grid',
          gap:10,
          marginTop:14,
        }}
      >
        {overview.isLoading && <p>Đang tải…</p>}

        {(data?.items ?? []).map(x => {
          const occupied=Boolean(x.residentId);
          const available=
            x.bedStatus === 'AVAILABLE';

          return (
            <article
              className="card"
              key={x.bedId}
            >
              <strong>
                {x.buildingName}
                {' / '}
                {x.floorName}
                {' / '}
                {x.roomName}
                {' / '}
                {x.bedName}
              </strong>

              <p>
                Trạng thái:{' '}
                <b>{x.bedStatus}</b>
              </p>

              {occupied ? (
                <>
                  <p>
                    {x.residentName}
                    {x.careLevel
                      ? ` · ${x.careLevel}`
                      : ''}
                  </p>

                  <button
                    type="button"
                    disabled={action.isPending}
                    onClick={() =>
                      action.mutate({
                        type:'RELEASE',
                        residentId:x.residentId!,
                      })
                    }
                  >
                    Trả giường
                  </button>
                </>
              ) : (
                <>
                  {residentId && (
                    <button
                      type="button"
                      disabled={
                        action.isPending ||
                        !available
                      }
                      onClick={() =>
                        action.mutate(
                          selectedResident?.bedId
                            ? {
                                type:'TRANSFER',
                                residentId,
                                bedId:x.bedId,
                              }
                            : {
                                type:'ASSIGN',
                                bedId:x.bedId,
                              },
                        )
                      }
                    >
                      {selectedResident?.bedId
                        ? 'Chuyển giường'
                        : 'Xếp giường'}
                    </button>
                  )}

                  {x.bedStatus === 'AVAILABLE' && (
                    <>
                      <button
                        type="button"
                        disabled={action.isPending}
                        onClick={() =>
                          action.mutate({
                            type:'STATUS',
                            bedId:x.bedId,
                            status:
                              'TEMPORARILY_UNAVAILABLE',
                          })
                        }
                      >
                        Tạm ngưng
                      </button>

                      <button
                        type="button"
                        disabled={action.isPending}
                        onClick={() =>
                          action.mutate({
                            type:'STATUS',
                            bedId:x.bedId,
                            status:'MAINTENANCE',
                          })
                        }
                      >
                        Bảo trì
                      </button>
                    </>
                  )}

                  {[
                    'TEMPORARILY_UNAVAILABLE',
                    'MAINTENANCE',
                  ].includes(x.bedStatus) && (
                    <button
                      type="button"
                      disabled={action.isPending}
                      onClick={() =>
                        action.mutate({
                          type:'STATUS',
                          bedId:x.bedId,
                          status:'AVAILABLE',
                        })
                      }
                    >
                      Đưa lại vào sử dụng
                    </button>
                  )}
                </>
              )}
            </article>
          );
        })}
      </section>

      <div
        style={{
          display:'flex',
          gap:8,
          marginTop:14,
          alignItems:'center',
        }}
      >
        <button
          type="button"
          disabled={!canPrev}
          onClick={() =>
            setOffset(
              Math.max(0,offset-PAGE_SIZE),
            )
          }
        >
          Trang trước
        </button>

        <span>
          {data?.total ?? 0} giường
        </span>

        <button
          type="button"
          disabled={!canNext}
          onClick={() =>
            setOffset(offset+PAGE_SIZE)
          }
        >
          Trang sau
        </button>
      </div>

      <details
        className="card"
        style={{marginTop:20}}
      >
        <summary>Thiết lập cơ sở lưu trú</summary>

        <div
          style={{
            display:'grid',
            gap:14,
            marginTop:14,
          }}
        >
          <div>
            <h3>Tòa nhà</h3>
            <input
              placeholder="Mã"
              value={bCode}
              onChange={e => setBCode(e.target.value)}
            />
            <input
              placeholder="Tên"
              value={bName}
              onChange={e => setBName(e.target.value)}
            />
            <button
              type="button"
              onClick={() =>
                setup.mutate('BUILDING')
              }
            >
              Tạo tòa nhà
            </button>
          </div>

          <div>
            <h3>Tầng</h3>
            <select
              value={fBuilding}
              onChange={
                e => setFBuilding(e.target.value)
              }
            >
              <option value="">
                Chọn tòa nhà
              </option>
              {(buildings.data ?? []).map(x => (
                <option
                  key={x.buildingId}
                  value={x.buildingId}
                >
                  {x.name}
                </option>
              ))}
            </select>

            <input
              placeholder="Mã tầng"
              value={fCode}
              onChange={e => setFCode(e.target.value)}
            />
            <input
              placeholder="Tên tầng"
              value={fName}
              onChange={e => setFName(e.target.value)}
            />
            <button
              type="button"
              onClick={() =>
                setup.mutate('FLOOR')
              }
            >
              Tạo tầng
            </button>
          </div>

          <div>
            <h3>Phòng</h3>
            <select
              value={rFloor}
              onChange={
                e => setRFloor(e.target.value)
              }
            >
              <option value="">
                Chọn tầng
              </option>
              {(floors.data ?? []).map(x => (
                <option
                  key={x.floorId}
                  value={x.floorId}
                >
                  {x.name}
                </option>
              ))}
            </select>

            <input
              placeholder="Mã phòng"
              value={rCode}
              onChange={e => setRCode(e.target.value)}
            />
            <input
              placeholder="Tên phòng"
              value={rName}
              onChange={e => setRName(e.target.value)}
            />
            <button
              type="button"
              onClick={() =>
                setup.mutate('ROOM')
              }
            >
              Tạo phòng
            </button>
          </div>

          <div>
            <h3>Giường</h3>
            <select
              value={bedRoom}
              onChange={
                e => setBedRoom(e.target.value)
              }
            >
              <option value="">
                Chọn phòng
              </option>
              {(rooms.data?.items ?? []).map(x => (
                <option
                  key={x.roomId}
                  value={x.roomId}
                >
                  {x.name}
                </option>
              ))}
            </select>

            <input
              placeholder="Mã giường"
              value={bedCode}
              onChange={
                e => setBedCode(e.target.value)
              }
            />
            <input
              placeholder="Tên giường"
              value={bedName}
              onChange={
                e => setBedName(e.target.value)
              }
            />
            <button
              type="button"
              onClick={() =>
                setup.mutate('BED')
              }
            >
              Tạo giường
            </button>
          </div>
        </div>

        {setup.error && (
          <p role="alert">
            {setup.error instanceof Error
              ? setup.error.message
              : 'Không thể tạo dữ liệu.'}
          </p>
        )}
      </details>
    </main>
  );
}
TSX

echo "PASS: FRONTEND OPERATIONAL UI"

echo
echo "STEP 5 — NAVIGATION"

python3 - "$NAV_FILE" <<'PY'
from pathlib import Path
import sys, re

p=Path(sys.argv[1])
s=p.read_text()

if "/accommodation" not in s:
    m=re.search(r"<nav\b[^>]*>",s,flags=re.I|re.S)
    if not m:
        raise SystemExit("NAV_OPEN_TAG_NOT_FOUND")

    insert='\n        <a href="/accommodation">Phòng &amp; Giường</a>'
    s=s[:m.end()]+insert+s[m.end():]
    p.write_text(s)
PY

grep -q '/accommodation' "$NAV_FILE" ||
  fail "NAVIGATION_ENTRY_MISSING"

echo "PASS: NAVIGATION"

echo
echo "STEP 6 — BUILD + BUNDLE"

(
  cd "$API"
  npm run build
) || fail "API_BUILD_FAILED"

(
  cd "$FE"
  npm run build
) || fail "FRONTEND_BUILD_FAILED"

MAIN_GZIP=0
AA_GZIP=0

for F in "$FE"/dist/assets/*.js
do
  [ -f "$F" ] || continue
  GZ="$(gzip -c "$F" | wc -c | tr -d ' ')"
  B="$(basename "$F")"

  case "$B" in
    AccommodationPage-*.js)
      AA_GZIP="$GZ"
      ;;
    *)
      [ "$GZ" -gt "$MAIN_GZIP" ] &&
        MAIN_GZIP="$GZ"
      ;;
  esac
done

echo "MAIN_MAX_JS_GZIP=$MAIN_GZIP"
echo "AA_ROUTE_GZIP=$AA_GZIP"

[ "$MAIN_GZIP" -le 153600 ] ||
  fail "MAIN_BUNDLE_OVER_150KIB"

[ "$AA_GZIP" -gt 0 ] ||
  fail "AA_LAZY_CHUNK_MISSING"

[ "$AA_GZIP" -le 81920 ] ||
  fail "AA_ROUTE_OVER_80KIB"

echo "PASS: BUILD + BUNDLE"

echo
echo "STEP 7 — ISOLATED SCALE DATABASE"

PG_IMAGE="$(docker inspect "$MASTER_PG" \
  --format '{{.Config.Image}}')"

PG_PASS="$(docker inspect "$MASTER_PG" \
  --format '{{range .Config.Env}}{{println .}}{{end}}' |
  sed -n 's/^POSTGRES_PASSWORD=//p' |
  head -1)"

[ -n "$PG_PASS" ] ||
  fail "POSTGRES_PASSWORD_NOT_FOUND"

docker exec "$MASTER_PG" pg_dump \
  -U "$DBU" \
  -d "$MASTER_DB" \
  --no-owner \
  --no-acl \
  -Fc \
  -f "/tmp/aa_c3_master_${STAMP}.dump" ||
  fail "MASTER_READONLY_DUMP_FAILED"

docker cp \
  "$MASTER_PG:/tmp/aa_c3_master_${STAMP}.dump" \
  "$TMP/master.dump" >/dev/null ||
  fail "COPY_MASTER_DUMP_FAILED"

docker network create "$NET" >/dev/null ||
  fail "ISOLATED_NETWORK_CREATE_FAILED"

docker run -d \
  --name "$IPG" \
  --network "$NET" \
  -e POSTGRES_USER="$DBU" \
  -e POSTGRES_PASSWORD="$PG_PASS" \
  -e POSTGRES_DB="$ISO_DB" \
  "$PG_IMAGE" >/dev/null ||
  fail "ISOLATED_POSTGRES_START_FAILED"

PG_READY=0
for _ in $(seq 1 120)
do
  if docker exec "$IPG" pg_isready \
    -U "$DBU" \
    -d "$ISO_DB" >/dev/null 2>&1
  then
    PG_READY=1
    break
  fi
  sleep .25
done

if [ "$PG_READY" -ne 1 ]
then
  echo "ISOLATED_POSTGRES_INSPECT:"
  docker inspect "$IPG" --format 'STATUS={{.State.Status}} RUNNING={{.State.Running}} EXIT={{.State.ExitCode}} ERROR={{.State.Error}} OOM={{.State.OOMKilled}}' 2>/dev/null || true
  echo "ISOLATED_POSTGRES_LOG_TAIL:"
  docker logs --tail 120 "$IPG" 2>&1 || true
  fail "ISOLATED_POSTGRES_NOT_READY"
fi

docker cp "$TMP/master.dump" \
  "$IPG:/tmp/master.dump" >/dev/null

docker exec "$IPG" pg_restore \
  -U "$DBU" \
  -d "$ISO_DB" \
  --clean \
  --if-exists \
  --no-owner \
  --no-acl \
  /tmp/master.dump >/dev/null ||
  fail "ISOLATED_RESTORE_FAILED"

docker cp "$MIG" \
  "$IPG:/tmp/aa_migration.sql" >/dev/null

docker exec "$IPG" psql \
  -v ON_ERROR_STOP=1 \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -f /tmp/aa_migration.sql >/dev/null ||
  fail "ISOLATED_MIGRATION_FAILED"

echo "PASS: ISOLATED DB + MIGRATION"

echo
echo "STEP 8 — SEED 500 BEDS"

cat > "$TMP/scale.sql" <<'SQL'
INSERT INTO accommodation_buildings(
  building_id,code,name,status,sort_order
)
VALUES(
  'scale-building',
  'SCALE',
  'Scale Building',
  'ACTIVE',
  1
);

INSERT INTO accommodation_floors(
  floor_id,
  building_id,
  code,
  name,
  floor_number,
  status,
  sort_order
)
SELECT
  'scale-floor-'||g,
  'scale-building',
  'F'||g,
  'Floor '||g,
  g,
  'ACTIVE',
  g
FROM generate_series(1,5) g;

INSERT INTO accommodation_rooms(
  room_id,
  floor_id,
  code,
  name,
  room_type,
  status,
  sort_order
)
SELECT
  'scale-room-'||f||'-'||r,
  'scale-floor-'||f,
  'R'||f||'-'||r,
  'Room '||f||'-'||r,
  'STANDARD',
  'AVAILABLE',
  r
FROM generate_series(1,5) f
CROSS JOIN generate_series(1,20) r;

INSERT INTO accommodation_beds(
  bed_id,
  room_id,
  code,
  name,
  status,
  sort_order
)
SELECT
  'scale-bed-'||f||'-'||r||'-'||b,
  'scale-room-'||f||'-'||r,
  'B'||b,
  'Bed '||b,
  'AVAILABLE',
  b
FROM generate_series(1,5) f
CROSS JOIN generate_series(1,20) r
CROSS JOIN generate_series(1,5) b;
SQL

docker cp "$TMP/scale.sql" \
  "$IPG:/tmp/scale.sql" >/dev/null

docker exec "$IPG" psql \
  -v ON_ERROR_STOP=1 \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -f /tmp/scale.sql >/dev/null ||
  fail "SCALE_SEED_FAILED"

BED_COUNT="$(docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -Atc "SELECT count(*) FROM accommodation_beds;")"

[ "$BED_COUNT" -ge 500 ] ||
  fail "SCALE_BED_COUNT_$BED_COUNT"

echo "AA_SCALE_BEDS=$BED_COUNT"
echo "PASS: SCALE DATA"

echo
echo "STEP 9 — BUILD + START ISOLATED API"

docker build -t "$IMG" "$API" >/dev/null ||
  fail "ISOLATED_API_IMAGE_BUILD_FAILED"

docker run -d \
  --name "$IAPI" \
  --network "$NET" \
  -p 127.0.0.1::3000 \
  -e NODE_ENV=test \
  -e DATABASE_URL="postgresql://$DBU:$PG_PASS@$IPG:5432/$ISO_DB" \
  "$IMG" >/dev/null ||
  fail "ISOLATED_API_START_FAILED"

PORT="$(docker port "$IAPI" 3000/tcp |
  head -1 |
  sed 's/.*://')"

[ -n "$PORT" ] ||
  fail "ISOLATED_API_PORT_MISSING"

READY=0

for _ in $(seq 1 60)
do
  C="$(curl -sS \
    -o /dev/null \
    -w '%{http_code}' \
    "http://127.0.0.1:$PORT/api/health" \
    2>/dev/null || true)"

  if [ "$C" = "200" ]; then
    READY=1
    break
  fi

  sleep .25
done

[ "$READY" = "1" ] ||
  fail "ISOLATED_API_NOT_READY"

ACT="$(docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -AtF '|' \
  -c "
SELECT actor_id,primary_operational_role
FROM staff_actors
WHERE status='ACTIVE'
AND primary_operational_role IN(
  'SUPERVISOR',
  'CARE_MANAGER'
)
ORDER BY
  CASE primary_operational_role
    WHEN 'SUPERVISOR' THEN 1
    ELSE 2
  END
LIMIT 1;")"

[ -n "$ACT" ] ||
  fail "NO_MANAGEMENT_ACTOR"

AID="${ACT%%|*}"
AROLE="${ACT#*|}"

R1="$(docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -Atc "
SELECT resident_id
FROM residents
ORDER BY resident_id
LIMIT 1;")"

[ -n "$R1" ] ||
  fail "NO_RESIDENT"

BASE="http://127.0.0.1:$PORT/api/accommodation"
OUT="$TMP/out.json"

echo "ISOLATED_API_PORT=$PORT"
echo "ACTOR=$AID|$AROLE"
echo "RESIDENT=$R1"
echo "PASS: ISOLATED API READY"

echo
echo "STEP 10 — BOUNDED OVERVIEW CONTRACT"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  "$BASE/overview?limit=100&offset=0" || true)"

[ "$C" = "200" ] ||
  fail "OVERVIEW_HTTP_$C"

read -r ITEM_COUNT TOTAL_COUNT LIMIT_VALUE <<EOF
$(python3 - "$OUT" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print(
    len(d.get("items",[])),
    int(d.get("total",0)),
    int(d.get("limit",0)),
)
PY
)
EOF

echo "OVERVIEW_PAGE_ITEMS=$ITEM_COUNT"
echo "OVERVIEW_TOTAL=$TOTAL_COUNT"
echo "OVERVIEW_LIMIT=$LIMIT_VALUE"

[ "$ITEM_COUNT" -le 100 ] ||
  fail "OVERVIEW_NOT_BOUNDED"

[ "$LIMIT_VALUE" = "100" ] ||
  fail "OVERVIEW_LIMIT_CONTRACT_INVALID"

[ "$TOTAL_COUNT" -ge 500 ] ||
  fail "OVERVIEW_TOTAL_NOT_SCALE_AWARE"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  "$BASE/overview?limit=101&offset=0" || true)"

[ "$C" = "400" ] ||
  fail "OVERVIEW_LIMIT_GUARD_EXPECTED_400_GOT_$C"

echo "PASS: BOUNDED OVERVIEW"

echo
echo "STEP 11 — STATUS + RESERVED + CORE WORKFLOW"

BED1="$(docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -Atc "
SELECT bed_id
FROM accommodation_beds
WHERE bed_id LIKE 'scale-bed-%'
ORDER BY bed_id
LIMIT 1;")"

BED2="$(docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -Atc "
SELECT bed_id
FROM accommodation_beds
WHERE bed_id LIKE 'scale-bed-%'
ORDER BY bed_id
OFFSET 1
LIMIT 1;")"

[ -n "$BED1" ] &&
[ -n "$BED2" ] ||
  fail "SCALE_TEST_BEDS_MISSING"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data '{"status":"TEMPORARILY_UNAVAILABLE"}' \
  "$BASE/beds/$BED1/status" || true)"

[[ "$C" =~ ^20 ]] ||
  fail "SET_UNAVAILABLE_HTTP_$C"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data "{\"residentId\":\"$R1\"}" \
  "$BASE/beds/$BED1/assign" || true)"

[ "$C" = "409" ] ||
  fail "UNAVAILABLE_ASSIGN_EXPECTED_409_GOT_$C"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data '{"status":"AVAILABLE"}' \
  "$BASE/beds/$BED1/status" || true)"

[[ "$C" =~ ^20 ]] ||
  fail "RETURN_SERVICE_HTTP_$C"

docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -c "
UPDATE accommodation_beds
SET status='RESERVED'
WHERE bed_id='$BED1';" >/dev/null

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data "{\"residentId\":\"$R1\"}" \
  "$BASE/beds/$BED1/assign" || true)"

[ "$C" = "409" ] ||
  fail "RESERVED_ASSIGN_EXPECTED_409_GOT_$C"

docker exec "$IPG" psql \
  -X \
  -U "$DBU" \
  -d "$ISO_DB" \
  -c "
UPDATE accommodation_beds
SET status='AVAILABLE'
WHERE bed_id='$BED1';" >/dev/null

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data "{\"residentId\":\"$R1\"}" \
  "$BASE/beds/$BED1/assign" || true)"

[[ "$C" =~ ^20 ]] ||
  fail "NORMAL_ASSIGN_HTTP_$C"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data '{"status":"MAINTENANCE"}' \
  "$BASE/beds/$BED1/status" || true)"

[ "$C" = "409" ] ||
  fail "OCCUPIED_STATUS_EXPECTED_409_GOT_$C"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data "{\"bedId\":\"$BED2\"}" \
  "$BASE/residents/$R1/transfer" || true)"

[[ "$C" =~ ^20 ]] ||
  fail "TRANSFER_REGRESSION_HTTP_$C"

C="$(curl -sS \
  -o "$OUT" \
  -w '%{http_code}' \
  -X POST \
  -H "x-actor-id: $AID" \
  -H "x-actor-role: $AROLE" \
  -H 'content-type: application/json' \
  --data '{"reason":"C2_CLOSEOUT"}' \
  "$BASE/residents/$R1/release" || true)"

[[ "$C" =~ ^20 ]] ||
  fail "RELEASE_REGRESSION_HTTP_$C"

echo "PASS: STATUS + RESERVED + ASSIGN/TRANSFER/RELEASE"

echo
echo "STEP 12 — SCALE PERFORMANCE"

T="$TMP/times.txt"
: > "$T"

for _ in $(seq 1 30)
do
  curl -sS \
    -o /dev/null \
    -H "x-actor-id: $AID" \
    -H "x-actor-role: $AROLE" \
    -w '%{time_total}\n' \
    "$BASE/overview?limit=100&offset=0" \
    >> "$T"
done

P95="$(python3 - "$T" <<'PY'
import sys,math
a=sorted(
    float(x.strip())*1000
    for x in open(sys.argv[1])
    if x.strip()
)
i=max(0,math.ceil(len(a)*0.95)-1)
print(f"{a[i]:.2f}")
PY
)"

echo "SCALE_REQUESTS=30"
echo "SCALE_OVERVIEW_P95_MS=$P95"

python3 - "$P95" <<'PY' ||
exit 41
import sys
raise SystemExit(
    0 if float(sys.argv[1]) <= 500 else 1
)
PY

RC=$?
[ "$RC" = "0" ] ||
  fail "SCALE_P95_OVER_500MS"

echo "PASS: SCALE PERFORMANCE"

echo
echo "STEP 13 — UI CLOSEOUT CONTRACT"

grep -q "Chuyển giường" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_TRANSFER_MISSING"

grep -q "Tạm ngưng" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_UNAVAILABLE_MISSING"

grep -q "Đưa lại vào sử dụng" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_RETURN_SERVICE_MISSING"

grep -q "Tất cả tòa" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_BUILDING_FILTER_MISSING"

grep -q "Tất cả tầng" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_FLOOR_FILTER_MISSING"

grep -q "Tất cả phòng" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_ROOM_FILTER_MISSING"

grep -q "Tìm phòng, giường, cư dân" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_SEARCH_MISSING"

grep -q "Trang sau" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_PAGINATION_MISSING"

grep -q "Thiết lập cơ sở lưu trú" \
  "$FE/src/features/accommodation/AccommodationPage.tsx" ||
  fail "UI_SETUP_REGRESSION"

grep -q '/accommodation' "$NAV_FILE" ||
  fail "NAVIGATION_MISSING"

echo "PASS: UI CLOSEOUT CONTRACT"

echo
echo "STEP 14 — MASTER FINAL REGRESSION"

H1="$(curl -sS \
  -o /dev/null \
  -w '%{http_code}' \
  http://127.0.0.1:3000/api/health \
  2>/dev/null || true)"

[ "$H1" = "200" ] ||
  fail "MASTER_HEALTH_CHANGED"

MF="$(docker exec "$MASTER_PG" psql \
  -X \
  -U "$DBU" \
  -d "$MASTER_DB" \
  -Atc "
SELECT count(*)
FROM pg_tables
WHERE schemaname='public'
AND tablename IN (
  'accommodation_buildings',
  'accommodation_floors',
  'accommodation_rooms',
  'accommodation_beds',
  'bed_assignments',
  'accommodation_audit_events'
);" 2>/dev/null)"

[ "$MF" = "0" ] ||
  fail "MASTER_DATABASE_MUTATED"

echo "MASTER_HEALTH_FINAL=$H1"
echo "MASTER_AA_TABLES_FINAL=$MF"
echo "PASS: MASTER PRESERVED"

echo
echo "======================================================================"
echo " STATUS: AA OPERATIONAL CLOSEOUT C3 PASSED"
echo "======================================================================"
echo " AA_BOUNDED_OVERVIEW=PASS"
echo " AA_OVERVIEW_PAGE_SIZE=100"
echo " AA_OVERVIEW_SCALE_TOTAL=$TOTAL_COUNT"
echo " AA_OPERATIONAL_UI=PASS"
echo " AA_UI_ASSIGN=PASS"
echo " AA_UI_TRANSFER=PASS"
echo " AA_UI_RELEASE=PASS"
echo " AA_UI_STATUS_CONTROL=PASS"
echo " AA_UI_FILTERS_SEARCH=PASS"
echo " AA_UI_PAGINATION=PASS"
echo " AA_UI_SETUP=PASS"
echo " AA_NAVIGATION=PASS"
echo " AA_RESERVED_GENERIC_ASSIGNMENT=REJECTED"
echo " AA_OCCUPIED_STATUS_CHANGE=REJECTED"
echo " AA_API_BUILD=PASS"
echo " AA_FRONTEND_BUILD=PASS"
echo " AA_LAZY_BUNDLE_GZIP=$AA_GZIP"
echo " AA_MAIN_MAX_JS_GZIP=$MAIN_GZIP"
echo " AA_SCALE_BEDS=$BED_COUNT"
echo " AA_SCALE_OVERVIEW_P95_MS=$P95"
echo " AA_SCALE_PERFORMANCE=PASS"
echo " AA_CORE_WORKFLOW_REGRESSION=PASS"
echo " MASTER_HEALTH_FINAL=$H1"
echo " MASTER_AA_TABLES_FINAL=$MF"
echo " MASTER_DATABASE_MUTATION=NO"
echo " MASTER_RUNTIME_REDEPLOYMENT=NO"
echo
echo " AA_PRODUCT_ACCEPTED=YES"
echo " AA_C_CLOSED=YES"
echo " NEXT=MASTER_ROADMAP_UPDATE_THEN_RESIDENT_LIFECYCLE_Y"
echo " STOP_AND_RETURN_OUTPUT"
echo "======================================================================"
