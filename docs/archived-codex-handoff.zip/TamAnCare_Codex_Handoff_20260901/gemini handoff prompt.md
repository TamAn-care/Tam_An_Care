# Codex Start Prompt

You are taking over the TamAnCare codebase from an evidence-first, gate-controlled development process.

## Your first job is NOT to code

1. Read every file in `docs/` and the selected artifacts in `evidence/`.
2. Inspect the actual project filesystem and identify the current source, DB/runtime state, checkpoints, and result artifacts.
3. Do not initialize Git merely because no repo is present.
4. Do not mutate source/schema/database or restart accepted runtimes during initial reconciliation.
5. Produce a read-only reconciliation report answering:
   - Does an OPS-5 implementation/closeout acceptance artifact exist after FAST-1R?
   - Is OPS-6 accepted checkpoint intact?
   - Is OPS-7 still not authorized?
   - What exact evidence authorized AA despite the older X3 roadmap showing downstream series not started?
   - Is AA accepted source present and buildable?
   - Is Y3C source present and buildable?
   - Has Y4 already run? If yes, what is its exact acceptance result?
   - What is the exact next authorized gate?

## Known accepted/current evidence

- V/W historical status: closed/accepted.
- X historical authority: through X3-B4 accepted; old roadmap says X3-B5-A next and X4 not authorized.
- OPS-6: technical closeout PASS + human accepted.
- OPS-7: authority-recovery-only; implementation not authorized.
- OPS-5: authority discovery complete but acceptance gap in retrieved evidence.
- AA Room/Bed: newer closeout artifact says product accepted/closed.
- Y: Y3C implementation + isolated acceptance PASS, but product not accepted; Y4 closeout is next in located evidence.
- RLA-BR-01 business rule approved, not implementation-accepted.

## Non-negotiable constraints

- Do not invent missing gate scope.
- Do not skip a gate because a later gate passed.
- Do not rerun OPS-5 blindly.
- Preserve OPS-6 accepted baseline.
- Do not start OPS-8.
- No hard resident-count maximum; 200 concurrent residents is baseline only.
- Bounded/paginated queries; no load-all.
- Preserve canonical inventory, resident consumption, Care Plan, and W family-report domains; no duplicate ledgers/domains.
- Human actor required for mutations.
- AI cannot approve cost or lock cost periods.
- Preserve audit/history and rollback safety.
- Vietnamese-first staff UX.

After reconciliation, propose exactly ONE next controlled block with: purpose, authority, files touched, expected mutations, rollback, tests, PASS/FAIL criteria, and explicit stop condition. Do not execute it until authorized.
